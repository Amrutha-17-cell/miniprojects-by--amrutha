# config.py
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Sowmya21234',  # Replace with your MySQL password
    'database': 'flaskify'
}
